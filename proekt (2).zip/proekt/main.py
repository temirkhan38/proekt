from flask import Flask, render_template, request


app = Flask(__name__)

file = ""

score = 0

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/page2')
def useful():
    return render_template('useful.html')

@app.route('/page3')
def harm():
    return render_template('harm.html')

@app.route('/test')
def test1():
    return render_template('testq1.html')

@app.route('/test2')
def test2():
    global score

    answer = request.args.get('answer')

    if answer == 'c':  # правильный ответ
        score += 1

    return render_template('testq2.html')

@app.route('/test3')
def test3():
    global score

    answer = request.args.get('answer')

    if answer == 'a':  # правильный ответ
        score += 1

    return render_template('testq3.html')

@app.route('/test4')
def test4():
    global score

    answer = request.args.get('answer')

    if answer == 'b':  # правильный ответ
        score += 1

    return render_template('testq4.html')


@app.route('/final')
def final():
    global score

    answer = request.args.get('answer')

    if answer == 'd':
        score += 1

    return render_template('final.html', score=score)

app.run(debug=True)
